<?php

define('DB_SERVER','20.219.36.68');
define('DB_USER','root');
define('DB_PASS' ,'HKrtFr9UgxMz');
define('DB_NAME', 'ciladmin');
$connect = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);

$mapa = "SELECT * FROM Dumpers ";

$dbquery = mysqli_query($connect,$mapa);

$geojson = array( 'type' => 'FeatureCollection', 'features' => array());

while($row = mysqli_fetch_assoc($dbquery)){

  $marker = array(
      'type' => 'Feature',
      'properties' => array('title' => $row['Dumper_ID']." (".$row['Status'].")", 'weight' => $row['Weight'], 'capacity' => $row['Capacity'], 'status' => $row['Status']),
	  'geometry' => array('type' => 'Point', 'coordinates' => array( $row['Longitude'], $row['Latitude'] ) )
  );
  array_push($geojson['features'], $marker);
}

header('Content-type: application/json');
echo json_encode($geojson, JSON_NUMERIC_CHECK);
?>
